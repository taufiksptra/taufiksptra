# Memoirs Jekyll Theme by WowThemes - Change Log

## 2020-05-06, v1.0.2
- jquery 3.5.1

## 2020-04-07, v1.0.1
- responsive tweaks

## 2020-04-04, v1.0.0

