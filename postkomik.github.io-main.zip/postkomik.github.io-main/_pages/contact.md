---
layout: page
title: Contact
permalink: /contact
comments: false
---

<h1>Contact Us</h1>

Untuk Informasi Contact Bisa menghubungi melalui Chat whatsap Dan fitur ada di sebela bawah kiri atau bisa memalui email : Ahmadalwy@gmail.com
<p>Untuk Menghubungi lewat telpone = 0878 7897 0878 <br />
  Bila ingin pasang iklan silahkan hunbungin nomor telp tersebut atau bisa juga melalui email</p>


atau isi form ini dah gan

<script defer="" src="https://apps.elfsight.com/p/platform.js"></script>
<div class="elfsight-app-c5f8b2ae-d4b6-4cb5-a0a1-f146424f689b"></div>
