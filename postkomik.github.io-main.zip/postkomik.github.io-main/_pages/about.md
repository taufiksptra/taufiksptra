---
layout: page
title: About us
permalink: /about
comments: false
image: 
imageshadow: true
---

 Terimakasih sudah mau berkounjung di blog yang masih kecil dan juga jangan lupa untuk follow ya agar tidak ketinggalan informasi updatenya

Postkomik adalah Blog informasi dunia maya yang mudah mudahan memberikan manfaat buat kalian semua dan jangan lupa untuk meninggalkan komentar saat komentar di buka yah 

mengenai blog ini awal nya sih hanya iseng dan hobi untuk latihan menulis karna semakin maju nya duni digital kita ga bisa ketinggalan gitu aja apalagi dalam duani seni menulis nah adanya blogger memberikan fasilitas blog maka ane manfaatkan untuk menyalurkan hobi dan bakat walau masih malas malasan untuk mengapresiaknnya

