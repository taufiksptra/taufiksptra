---
layout: page
title: Room Chat  
permalink: /chatting
comments: false
image: 
imageshadow: true
--- 



<h1>Group Chat</h1>

<iframe width="100%" height="400px" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" allowtransparency="true" src="https://chatroll.com/embed/chat/kksr?id=XXwr8CvtNn5&platform=html"></iframe>
