---
layout: post
title:  "Pandangan Islam tentang kucing"
author: mas cemplon
categories: [ Cat Lover ]
tags: [ kucing ]
image: https://1.bp.blogspot.com/-Sa9ArdgaUK8/X_APU1Qm_bI/AAAAAAAAOMA/MLROrBEk7vsxlFrLfgL97ryVs-A9LKcFQCLcBGAsYHQ/w320-h195/kucing.jpg
beforetoc: "5 Alasan kucing tiba-tiba sering mengeong dengan keras, kenali maksudnya"
toc: true
---

Viral mengenai surat edaran Institut Teknologi Sepuluh Nopember (ITS) Surabaya soal kawasan bebas dari kucing liar.
Kucing-kucing ini dinilai mengganggu tamu kampus. Dalam sebuah penelitian yang dilakukan oleh Pete Marra selaku kepala Smithsonian Migratory Bird Center, kucing juga dianggap bisa merusak ekosistem karena membuat spesies burung menjadi punah

Padahal kucing ialah hewan yang menyenangkan dan memiliki wajah lucu. Tak jarang kucing juga memiliki sifat yang manja. Sejak zaman Rasulullah SAW, kucing disebut-sebut sebagai hewan kesayangan Nabi Muhammad

Ada sebuah hadist dari Abu Qotadah, Nabi SAW bersabda:

"Kucing itu tidaklah najis. Sesungguhnya kucing ialah hewan yang sering kita jumpai dan berada di sekeliling kita." (HR. At Tirmidzi, Abu Daud, An Nasa'i, Ibnu Majah, Ad Darimi, Ahmad, Malik.)

Bahkan Rasulullah saking senang dan sayang dengan kucing. Beliau pernah membiarkan seekor kucing menyelesaikan menikmati minumnya di bejana yang berisi air padahal beliau hendak berwudhu.

Dikutip dalam buku berjudul "Hak-hak yang Wajib Anda Ketahui dalam Islam" oleh Syaikh Muhammad Hassan, diceritakan ada seorang wanita dimasukkan ke neraka gara gara menyekap kucing dan tidak memberinya makan. Wanita ini juga tidak membiarkan kucing itu makan serangga-serangga tanah.

Dari Ibnu Umar RA Nabi Muhammad SAW bersabda, "Seorang wanita dimasukkan ke dalam neraka karena seekor kucing yang dia ikat dan tidak dibiarkan makan bahkan tidak diperkenankan makan binatang-binatang kecil yang ada di lantai." (HR Bukhari, Kitab Ahadits Al-Anbiya, 3467; Muslim, Kitab As-Salam, 2245)


Enter text in [Markdown](http://daringfireball.net/projects/markdown/). Use the toolbar above, or click the **?** button for formatting help.
