---
date: 2021-01-27 18:40:18
layout: post
title: "Why Change To Windows Vista: Part 2 of 4"
author: mas cemplon
categories: [ Computers, Technology ]
tags: [ Computers ]
image:
beforetoc: "Part 3 of a 4 part look at Microsoft's reasoning for upgrading to Vista.  The Tennessee Mountain Man and Computerman found flawed reasoning more like that of a third grader. The last part will be published tomorrow.."
toc: true
---
Microsoft, Windows, Vista, Windows Vista, Tennessee, Mountain Man, remote helpdesk, help desk, helpdesk, outsourced it services, remote computer repair, online computer repair, outsourced helpdesk, outsourced help desk, outsourced computer repair



Why Change To Windows Vista:  Part 3 of 4

We are almost there, this is part 3 of 4.  Actually it has somewhat more meat than Part 2, but once again starts trailing off towards the last few reasons covered by the Tennessee Mountain Man today.  Computer man can't help but wonder if a third grader actually did prepare Microsoft's reasons to smile or upgrade to Vista.

Enjoy.

MS#51. "Because you live to play"

The Tennessee Mountain Man actually wishes Microsoft had this one right for the average American.  But, alas Americans play less than the citizenry of most other countries.  Outsourced computer repair techs, unlike the money moguls at Microsoft, recognizes it now takes two people working not only full time but over time to feed and clothe the family.

"Because we love to play", may have been more accurate; but living to play?  Americans have long proven their propensity to live for work unfortunately.

Remote helpdesk 1 is the proof in the pudding!  Who has time for computer games?  As to whether Windows Vista makes the games easier, faster, more fun....give me a break.

MS#52. " Take control of game time"

Kudos !!

MS#53. "Because you can get more done when you work together"

Microsoft's brain storming appears to have produced great and long followed general rules for success in any endeavor.  
"The house divided against itself cannot stand".  Mutual cooperation on the job, in sports, or in family affairs goes a long way.

As to inviting people to work with you on projects over the Internet, a company network, or an ad-hoc wireless network....We had been doing that for years... long before Windows XP was corrupted to come up with Windows Vista simply to enrich Microsoft coffers.

MS#54. "Stay entertained wherever you go"

Some of these remind old online computer repair geezers of some of the motel ads on TV.  Come On!!!!!!!!!!  Wow!  Online helpdesk would have never thought of that little trick before Vista and without the help of Bill Gates!  N E X T !!!!!!!!!!!!!!!!!!!

MS#55. "Because success tomorrow starts today"

Amen!!!!! Today is the first day of the rest of your life, but P L E A S E  get a life.  Hopefully not after Microsoft's blueprint.

The rest of this reason, like most of their reasoning, appears to be little more than someone "making work" or needing to fill newspaper space.  Speaking of needing to get a life!

MS#56. "Print what you see"

Hogwash!!!!  Unlike the rest of mankind, apparently Microsoft never heard of Windows 3 or the "print screen" command.

MS#57. "Because you don't need a PC to watch your home movies"

Really?  Can you say Kodak?  How about Polaroid?  Well, don't!  Outsourced it services still needs the online pc repair work.

MS#58. "Fill your home with music"

Yes, please!  Music soothes the savage beast!  Maybe Microsoft needs something besides elevator music, however.
We used to do that with a radio which had a red light that burned when the radio was on.  As a lad the Tennessee Mountain Man used to set for hours with an eye glued to that light watching radio shows.  Those were the days!!!

Dacomputerman knows all about that! That was all before WMP 11 and Microsoft's control over his entertainment choices.

MS#59. "Make a masterpiece"

"Blend your photos and home videos into a rich movie experience, complete with soundtrack, titles and credits, and creative transitions."

So Microsoft can report you!  You do know, they know what you had for dinner last evening and whether you skipped breakfast this morning, don't you?  Listen....sounds like they are the phone with an artist formerly known as Prince now.

MS#60. "Because you want your video memories to stay true to life"

"Windows Movie Maker lets you retain high-definition quality as you capture, edit, and publish movies from your HD camcorder."

The remote computer repair folks told me this is "déjà vu all over again".  Dacomputerman thought he was just getting old and senile.

Oh, and don't forget this little ditty:  "Some product features are only available in certain editions of Windows Vista and may require advanced or additional hardware".

MS#61. "Stand strong against hackers"

"The easy-to-use Windows Firewall with Advanced Security provides advanced protection to help shield you and your PC from malicious attacks."

Come on...come on!  Stop laughing and get back to work.

MS#62. "Because it remembers what you like to doand helps you do it faster"

Please refer to MS#59 above!  Then go immediately to the Prefetch File located in C:\\Windows and dump it's contents.  Do this daily and note the improvement in OS response time.

MS#63. "Help is always available"

By now most people have learned to avoid the helpdesk of major computer companies including Microsoft...maybe especially Microsoft and certainly especially if your first language is English.

Fortunately also most people ignore the recommendation in this reasoning.  Otherwise a lot of us would be out of business.

MS#64. "Keep your files confidential"

Can you say, déjà vu once again?  Swamp land, anyone?  anyone?  how about a bridge?

MS#65 "Send a fax on the spot"

"Windows Fax and Scan makes sending and receiving faxes directly from your PC as simple as using e-mail. With fax templates linked to your address book, it's easy to retrieve a fax number, attach your documents, and just click to send."

Kudos!!!!!!  someone caught sleeping?!

MS#66. "Because everyone goofs sometimes"

Never heard of restore points before Vista ,huh?

MS#67. "Because e-mail is your lifeline"

"He who lives by the sword, dies by the sword".

MS#68. "Stay on top of your family's schedule"

The old magnet on the refrigerator didn't work, I doubt this will.  But maybe it will work better for you than for the old da computer man,

MS#69. "Because you want the quality of your printouts to match the quality of your work"

O.K.  Kudos!!!!!!!!

MS#70. "Your PC is ready when you are"

So is your significant other!!  Right.  Just keep the aspirin handy...headaches do happen! And, don't miss the standard little caveat at the end of the reasoning.

MS#71. "Keep your favorite things at your fingertips"

Favorite things have nothing to do with computers or Windows Vista.
Please excuse the computer man while he day dreams a bit.  Favorite things...O.K. unmentionable.  So move on to Meerschaum pipe, BCA smoking tobacco, Scotch, T Bone, Lobster....alright...alright...moving along.

MS#72. "Get the latest news delivered right to your desktop"

schhhhhhh!  Please don't tell Microsoft that these news tickers have been around forever.

MS#73. "Because your photos and home movies don't have to be stuck in your PC anymore"

ho!  hum!!

MS#74. "Because your memories need a little mood music"

How many times and ways can we say, déjà vu?

MS#75. "Because you want professional-looking photos from your own printer"

And, How many times can you take, déjà vu?  If only Microsoft had considered that question!!
tmm

