---
layout: post
title:  "Experiment kecepatan index url pada google search console"
author: mas cemplon
categories: [ Website ]
tags: [ website ]
image: https://1.bp.blogspot.com/-SQJeol8Y6cQ/YA-ad3v22DI/AAAAAAAAOkA/GdCqbcgiLJwQUHPjmg0AJeswaC0igcBKQCLcBGAsYHQ/gsc.webp
beforetoc: "Ini adalah eksperiment kecepatan index antara blogger dan blog statis
"
toc: true
---


<p><iframe width="100%" height="315" src="https://www.youtube.com/embed/z5mkPZnFpc0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></p>


dalam expertiment ini artikel di buat pada tanggal 26 januari 2021 dan perbandingannya yaotu antara dua blog yaitu :

Blogger dan Blog statis

Nah Besok nanti dicek mana yang lebih cepat terindex. tapi sebelumnya mengenai post ini hanya jejak sajaagar lebih meyakinkan kalau hitungannya bisa di mulai dari jejak index nya hmm ya gitulah 

Dan tunggu besok deh hasil nya 
