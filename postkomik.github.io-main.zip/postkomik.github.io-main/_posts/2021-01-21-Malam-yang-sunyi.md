---
layout: post
title:  "Malam yang sunyi."
author: mas cemplon
categories: [ Puisi, Rangkaian kata ]
tags: [ puisi ]
image: https://images.unsplash.com/photo-1587200292891-9b3a506060f6?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80
beforetoc: "Wow Bintang sudah mulai berkedip langit pun terasa indah."
toc: true
---

Malam Yang Sunyi 

Wow Bintang sudah mulai berkedip

langit pun terasa indah

Padahal awan awan ingin berjalan dan bersanding

Burung burung mulai lelah bersiul

Angin Mulai mondar mandir menyelinap kedinginan

Hawa dingin mulai memeluk

Suara Hati terrnyuh untuk menikmati

Oh di mana ini

Di bumi kah 



Tak terasa sudah berapa lama ku melamun dan hayalan mulai meninggi di kesunyian

Dan Mulai memetik kata dalam rasa yang sudah di racik

Kata Kata Lamunan Malam 

Entah apa yang mesti di ungkap

Setitik tetesan pena sudah siap untuk menari kata kata

Sepucuk kertas sudah siap berdandan rapih

Segelas kopi sudah siap mengusir asap asap panas nya



Kata Kata Bijak ini harus tersampaikan

Hmm berapa lama ku mencoba meracik ide

padahal kaki sudah bersandar di bumi ini mulai lelah

Punggung sudah mulai meneteskan air keringat 

Mulai ku menulis .........

oh dunia ada apa dengan mu

Kedamaian ini becampur dengan kesunyian

Berapa alam ini akan menemani malam yang indah ini

hmm Hati kecil bertanya apa itu malam

Malam adalah hal yang sangat di nantikan bagi kawan kawan untuk menulis dan myimpan sebuah ide yang akan di susun

Berapa banyak yang mesti di tulis.....

Ratusan kah

Ribuan kah

Atau jutaan........

Mungkin setitik demi setitik akan tertulis

Tak peduli Rintangan apa yang datang

Inilah awal perjuangan penulisan

Capstion malam singkat...... tanks
