---
layout: post
title:  "Blog whit blogger"
author: mas cemplon
categories: [ Pendidikan ]
image: https://images.unsplash.com/photo-1522199755839-a2bacb67c546?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=752&q=80
beforetoc: "Blogger is one of the many options available to bloggers who are looking for free blog software. This website located at the following web address: http://www.blogger.com."
toc: true
---


 Blogger is one of the many options available to bloggers who are looking for free blog software. This website located at the following web address: http://www.blogger.com offers registered users the opportunity to publish their own blog free of charge. The website also has templates the blogger can use to create his blog and even enables bloggers to easily place Google advertisements on their blog and coordinates an AdSense account for the users so they can potentially earn a profit from their blog. This article will discuss the history of Blogger as well as the terms of service. 



The History of Blogger



Blogger began in 1999 with a small group of friends in the San Francisco area who ran a company called Pyra Labs. These friends did not set out to create a network of bloggers but nevertheless Blogger emerged from their efforts. The three friends who developed bloggers were programmers who toiled away for others in an effort to fund their own endeavors. As previously mentioned a blog network was not their original goal but the friends were intrigued by the idea as it emerged and found others were interested too as their concept quickly took off and new members were joining everyday. Like most Internet entrepreneurs of this time period, they experienced setbacks but continued to persevere.



In 2002 Blogger was doing well but got an unexpected surprise when Google expressed interest in purchasing Pyra Labs. Google was interested in the upswing in the blogging community and the members of Pyra Lab sold their company enabling Google to take over the operation. Since taking over Google introduced the concept of AdSense advertising campaigns on blogs which has been generating profits for Google and bloggers alike. Blogger not only offers members templates to create a blog and voice their opinions on the Internet but also simplifies the process of placing AdSense advertisements on the blog. 



Blogger Terms of Service



The Terms of Service of Blogger are susceptible to change but there are a few basic terms which users can expect to exist. The Terms of Service for Blogger provides explanations of items such as the services offered, description of proper use of the services, privacy policies, an explanation of intellectual property rights, cause for termination and information regarding the legal jurisdiction of the website. Members of Blogger are advised to carefully review these policies before becoming a member and to be sure they understand and agree to all of these terms. If the potential member is unsure about the meaning of one or more of the terms, he should contact Blogger to seek clarification on the Terms of Service. 



Members of Blogger should also be aware that the Terms of Service may change and should review these terms periodically to ensure there have been no changes made which will adversely impact the member. 



Members of Blogger should pay particular attention to the section of the Terms of Service which specify causes for termination of a members account. This information is important because it will help to prevent the member from inadvertently performing an action which may result in his account being terminated or suspended. Blogger is not required to inform the member of the infractions before suspending the account so a member will likely lose his account before he is even aware he has violated the Terms of Service agreement.
