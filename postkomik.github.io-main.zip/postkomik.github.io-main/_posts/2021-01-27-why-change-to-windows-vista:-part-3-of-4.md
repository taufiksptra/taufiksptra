---
date: 2021-01-27 18:39:42
layout: post
title: "Why Change To Windows Vista:  Part 3 of 4"
author: mas cemplon
categories: [ Computers, Technology ]
tags: [ Computers ]
image:
beforetoc: "Part 2 of 4 of a look at Microsoft's 100 top reasons to change to the Vista operating system.  One Hundred reasons to smile according to Microsoft.  Not so fast says The Tennessee Mountain Man.."
toc: true
---
Microsoft, Windows, Vista, Windows Vista, Tennessee, Mountain Man, remote helpdesk, help desk, helpdesk, outsourced it services, remote computer repair, online computer repair, outsourced helpdesk, outsourced help desk, outsourced computer repair


Why Change To Windows Vista: Part 2 of 4

Having caught his breath and dispatched the laugh monster (just in time for Halloween) the Tennessee Mountain Man is ready to resume his look at Microsoft's 100 Reasons Why we should be using Windows Vista.

In Part 1 of Why Change To Windows Vista, Remote Helpdesk 1, examined Microsoft's reasons 1 through 25.  Today we will cover reasons 26 - 50 so lets get started.

MS#26. "Because you're a multitasker"

While Scientific studies reveal the hidden costs of multitasking as technology increasingly tempts people to do more than one thing at a time Bill Gates and Microsoft keep pushing for more.

If anyone were tempting Microsoft employees to use anything other than best practices there would be one of Microsoft's infamous law suits.

Aren't all of us forced to multi task toooo much as it is?  Back off Gates!

MS#27. " Because your computer can keep up with you while you're on the go"

Lik
e the pager and the cell phone, the curse of the hand held, laptop, note book and other portables is that all technology, including our computers, have kept up with us too well...no uninterrupted vacations, dinners, shows, golf games, or romantic sessions.  Get this contraption out of my bedroom!

MS#28. "Enjoy your memories, larger than life"

Sorry, The Tennessee Mountain Man finds nothing new here.

MS#29. "Take the handwritten approach"

O.K. Been around forever.  Ever checked out at the store or used an ATM with a touch screen?  How about Monday Night Football?  Been there, done that.

MS#30. "Restore your PC in an instant"

Hello!  I know I am not as smart as the Microsoft gurus but haven't that covered this already, in Part 1 maybe?!  I guess that is why he is Bill Gates owning Microsoft and I own a remote helpdesk performing online computer repair services.

In the army we taught by telling students what we were going to teach them, doing the teaching, and then reiterating what we had told them.  But, we didn't try to cover it up calling it three different lectures.

P.S.  Don't miss their last caveat.

MS#31. "Because your PC lets you know if something's wrongand helps you fix it"

Sorry, The Tennessee Mountain Man could find nothing new here either unless the user has been more lazy than most.  It was all available with earlier, faster, less expensive, and less intrusive operating systems.

Now the Tennessee Mountain Man is in danger of becoming repetitive, but Microsoft is not giving me anything to work with here.

MS#32. "Streamline IT management across your business"

Oh!!!!! So!!!!!!! It is actually just an upgrade Microsoft Server 2003 with all the patches and fixes included.

MS#33. "Preserve a lifetime of memories"

It has a back up feature!!!!  Really?

MS#34. "Connect to the network at work or school"

Not to mention connecting at your motel, Mickey D's, your grand ma's, and a million other places.  Kids and businessmen have been doing this for years...Next!

MS#35. "Because you'll know it when you see it"

And we haven't seen it yet....moving right along....

MS#36. "Get a "do-over" when you need it"

And I have some swamp property I need to unload before you lose everything.

MS#37. "Keep your info under lock and key"

This may be the best reason so far. But, let's face it, if Microsoft and the U.S. Government can't keep hackers out of their own stuff do you really think you have a chance?

On the other hand, have you lost the pass words to get into today's IBM laptops?

MS#38. "It's the cure for red-eye"

No, they were not brazen enough to say it would keep you from working nights.  What they are doing is touting an existing technology.

MS#39. "Relive your memorieseach and every one"

O.K. Microsoft likes to be redundant, remote computer repair services does not.

MS#40. "Because you love what you do"

Especially when the windows operating don't crash or lock up, and performs more reliably like Ubuntu.

But watch Microsoft's caveat at the end of this reasoning.

MS#41. "Because your PC will stay up to date, automatically"

Has it not done that for years?   Oh, yes, I'm sorry.  The Tennessee Mountain Man almost forgot.  This is apparently our warning that Microsoft will come through the back door and make any changes they want whenever they wish despite our desires and upgrade and maintenance settings.

MS#42. "E-mail your photos without worrying about the file size"

Oh, really?  The ISP on each end of the spectrum may have different ideas.

MS#43. "It's parent friendly"

What is that supposed to mean?  It is slow?  Because it is!

Oh, sorry they are referring to parental controls like the ones parents and bosses have used forever.  Got it.

MS#44. "Because you have a need for speed"

"Need to speed up your computer? Simply plug a USB memory stick into your desktop or notebook computer and let Windows ReadyBoost do the rest."

O.K., I could, but I won't.  Kudos!!!!!!!!

MS#45. "Because you hate all those boxes and wires"

That is why we had already eliminated them.....next...

MS#46. "Your music can look as good as it sounds"

At Branson maybe!  Now just what does this do that is an improvement over XP?

MS#47. "Let the fun start now"

Are we having fun yet?  No!!!!!!!

MS#48. "Stay connected wherever you go"

Duh!!!!!!  We just covered this subject!

MS#49. "Take your workspace with you"

Although Microsoft remains redundant, I can't help but respond....The labor laws of the U.S. makes provisions for breaks and meal times.

I want to get away on occasion and Microsoft wants a robot chasing me around demanding more...more...more...more!

MS#50. "Get more out of the web"

Watch the caveat as Microsoft makes a johnny come lately feeble attempt to catch up with other browsers.

Is the Tennessee Mountain Man speechless yet?  No, but we'll take another stab at it tomorrow with "Why Change To Windows Vista:  Part 3 of 4".
tmm