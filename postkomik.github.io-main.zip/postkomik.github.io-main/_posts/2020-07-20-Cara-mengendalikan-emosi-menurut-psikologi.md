---
layout: post
title:  "Cara mengendalikan emosi menurut psikologi"
author: mas cemplon
categories: [ Karakter ]
tags: [ Tips ]
image: https://1.bp.blogspot.com/-xG7pF5mj1Po/YAkW8PRTUOI/AAAAAAAAOT0/thrHSc2al4kVo4JKoKkW_fVCwEfifqVYwCLcBGAsYHQ/s1000/brett-jordan-nd2fFCkXWTw-unsplash.jpg
beforetoc: "Cara mengendalikan emosi menurut psikologi."
toc: true
--- 

Pengendalian Emosi

Saat perasaan intens yang di tunjukan pada seseorang atau sesuatu itulah emosi. Yang merasakan emosi sudah pasti mahluk hidup seperti manusia hewan dan tumbuhan tapi berbeda cara menyampikan emosinya atau perasaan emosinya. Hal ini manusia merasakan emosi secara umum saat terjadi penolakan rasa di hati yaitu marah. 

Walau sebab terjadinya emosi bisa di mulai dari hal hal kecil atau besar . adanya sebab dan akibat yang menghasilkan emosi. Saat di hina pasti akan muncul perasaan emosi yaitu marah,kesal dan panas hati. Meski dalam kondisi apapun dan dimanapun kita berada ika ada yang menyulut nya makan di situlah rasa marah akan naik dratis .
lalu bagai mana cara mengatasinya ?

Renungan Saat Marah
Setiap manunia memnag beda tiap menghadapi kemarahan. Ada yang memiliki sifat sabar dan mampu menahan emosionalnya saat sudah mencapai puncak. Tapi tidak mudah untuk mengontrolnya. Mengapa
mungkin diperlukan sebuah tehnik atau pengalamn hidup nya yang sudah membantunya
