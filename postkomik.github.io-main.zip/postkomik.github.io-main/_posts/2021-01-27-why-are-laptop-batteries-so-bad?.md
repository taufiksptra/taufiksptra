---
date: 2021-01-27 18:38:10
layout: post
title: "Why Are Laptop Batteries So Bad?"
author: mas cemplon
categories: [ Computers, Technology ]
tags: [ Computers ]
image:
beforetoc: "If you are like most people with laptops you know that they are only as portable as the nearest outlet. The companies advertise like their laptop batteries make these machines so that they can go anywhere with you and there will be no problem but there is a problem. You only have a couple hours max of normal word processing type use and then you are toast unless you either have a backup battery or you can plug in somewhere and recharge. The other problem is that lots of place...."
toc: true
---
If you are like most people with laptops you know that they are only as portable as the nearest outlet. The companies advertise like their laptop batteries make these machines so that they can go anywhere with you and there will be no problem but there is a problem. You only have a couple hours max of normal word processing type use and then you are toast unless you either have a backup battery or you can plug in somewhere and recharge. The other problem is that lots of places that you go and that you would love to use a laptop at aren�t able to supply outlets to everyone and so you are up a creek as they say.

So my main question for this piece is why are laptop batteries so bad? To answer this question I am going to do a quick search on the internet and try to quickly glean as much information as I can in the next few minutes and then I will proceed to pack it in to the next 2 paragraphs or so. Here I go�.

Well we will start with what most batteries are made of and that is Lithium Ion cells (older laptop batteries were made of nickel cadmium). These batteries have several advantages including no memory and no scheduled cycling (That does not mean however that it is a good idea to repeatedly run your battery dead). These batteries are therefore low maintenance. However because their cell oxidation can not be reversed through cycling there is a definite and short lifespan for these batteries. This turns out to be around two to three years and is not necessarily lengthened by not using as oxidation goes on in the form of self discharge even when stored.

Now it is recommended that one stores the battery at about 40% capacity and in a cool place. The 40% capacity gives it the ability to self discharge slowly without going all the way dead (which is bad for these laptop batteries, if you recall). These batteries will oxidize more slowly in cooler temperatures which prolongs the life. These power cells are not meant for long term storage as already mentioned because the self discharge will drain it sometimes to the point of no return.

The reason why these new laptop batteries are so much more expensive than they used to be is because they require an internal circuit that prevents it from overcharging. Overcharging can cause the battery to heat up and actually burst into flames.
