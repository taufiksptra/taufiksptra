---
layout: post
title:  "Home Schooling Requirements: Differences In States."
author: mas cemplon
categories: [ Pendidikan ]
tags: [ edukasi ]
image: https://images.unsplash.com/photo-1503676260728-1c00da094a0b?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=709&q=80
beforetoc: "Homeschooling has increased more in the past few years than it has for the past decades. Initially, homeschooling or any type of private education."
toc: true
---

Homeschooling has increased more in the past few years than it has for the past decades. Initially, homeschooling or any type of private education wasnt allowed in the United States, but when a public court ruled for the Society of Sisters for the Holy Names of Jesus and Mary and allowed them to set up a private school in 1925, public schools werent the only institutions providing education to children. This sparked the homeschooling idea and not long after, parents have decided to educate their children in their own homes.



Homeschooling is legal in all 50 states; however, each state has different requirements and guidelines reagrding the homeschooling program. Some states simply require parents who opt for homeschooling, to simply file an intent notice to the local school superintendent or any school official, and some require lesson plans to be made and approved by the school board before the program starts. All of these requirements aim to fully educate children whether they are educated at home or in public schools.



In California, homeschoolers have three choices, thay can use a credited tutor, enroll in a qualified private school or be part of an independent public homeschooling program. Parents may form private schools for their own children; however, all those who wish to form private schools need to file an annual report with the Department of Education. 



Certain courses, similar to that of public schools, that can fit into a few pages, (contrary to the hundreds of pages required of public schoosl) need to be present, as well as attendance records. But teachers need not have credentials, they must simply be capable of teaching.



Differences in state requirements can also be observed in testing and assessment. Some states require homeschoolers to take standardized tests or have evaluations done by qualified teachers. Other states however, do not require such evaluation methods. In California again, students are encouraged to take the standardized tests that Public Schools are implementing at the end of every term.



Graduating procedures also differ with states, some require that home schools be operated as private schools, have graduation procedures that doent differ from private school gradaution. However, some have no graduation requirements at all; basically, the schools determine who graduates or not, this applies to homeschoolers in the state as well. In other states, homeschoolers receive no recognition, but are still granted access to colleges and universities.



Requirements and laws differ from state to state, and there is no absolute list of requirements for the whole United States. The best a parent who intends to homeschool her child is to find web sites or go to local school officials for information.

